package com.qigetech.mark.result.label.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.qigetech.mark.origin.service.IOriginService;
import com.qigetech.mark.result.label.entity.LabelResult;
import com.qigetech.mark.result.label.service.ILabelResultService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import java.util.stream.Collectors;

import static org.junit.Assert.*;

/**
 * Created by panzejia on 2019-07-21
 * Project : qigetech-mark
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class LabelResultServiceImplTest {

    @Autowired
    private ILabelResultService labelResultServiceImpl;

    @Test
    public void getOriginListByRole() {
        Page<LabelResult> page = new Page<>(0,20);
        QueryWrapper<LabelResult> queryWrapper = new QueryWrapper<LabelResult>().orderByDesc("mark_date").groupBy("origin_id").eq("user_id",1);
        IPage<LabelResult> labelResultIPage = labelResultServiceImpl.page(page,queryWrapper);
        List<LabelResult> labelResults = labelResultIPage.getRecords();
        for(LabelResult result : labelResults){
            System.out.println(result.getOriginId());
        }
        List<Integer> originIds = labelResults.stream().map(LabelResult::getOriginId).collect(Collectors.toList());
        System.out.println(originIds);
    }
}