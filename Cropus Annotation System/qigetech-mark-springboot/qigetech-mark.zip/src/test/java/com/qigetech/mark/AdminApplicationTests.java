package com.qigetech.mark;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.hankcs.hanlp.tokenizer.NLPTokenizer;
import com.qigetech.mark.article.entity.Article;
import com.qigetech.mark.article.service.IArticleService;
import com.qigetech.mark.origin.entity.Origin;
import com.qigetech.mark.origin.entity.OriginStatus;
import com.qigetech.mark.origin.service.IOriginService;
import com.qigetech.mark.result.label.entity.LabelResult;
import com.qigetech.mark.result.label.mapper.LabelResultMapper;
import com.qigetech.mark.result.label.service.ILabelResultService;
import com.qigetech.utils.resultbundle.ResultBundleBuilder;
import org.apache.commons.io.FileUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AdminApplicationTests {

    @Autowired
    private IOriginService originServiceImpl;

    @Autowired
    private ILabelResultService labelResultServiceImpl;
    @Resource
    private LabelResultMapper labelResultMapper;
    @Autowired
    private ResultBundleBuilder resultBundleBuilder;
    @Autowired
    private IArticleService articleServiceImpl;
    @Test
    public void contextLoads() {
        for(int i=1;i<5;i++){
            Origin origin = new Origin();
            origin.setSentence("这是一个测试"+i);
            origin.setSystemLabel("这是/n 一个/n 测试/n "+i+"/num");
            origin.setLanguage("中文简体");
            origin.setSource("测试");
            originServiceImpl.save(origin);
        }
    }

    @Test
    public void test() throws IOException {
        Collection<File> files =  FileUtils.listFiles(new File("C:\\Users\\jaypa\\Desktop\\content"),null,false);
        for(File file : files){
            try{
                String text = FileUtils.readFileToString(file);
                String time = file.getName().split("。")[0]
                        .replaceAll("星期一","")
                        .replaceAll("星期二","")
                        .replaceAll("星期三","")
                        .replaceAll("星期四","")
                        .replaceAll("星期五","")
                        .replaceAll("星期六","")
                        .replaceAll("星期日","")
                        .replaceAll("年","-").replaceAll("月","-");
                String title = file.getName().split("。")[1].replaceAll(".txt","");
                text = text.replaceAll("＊","")
                        .replaceAll("　","")
                        .replaceAll(" ","")
                        .replaceAll("\t","")
                        .replaceAll("\n","");
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                if(isChinnese(text)){
                    Article article = new Article();
                    article.setSource("明报");
                    article.setContent(text);
//                    article.setTitle(title);
                    article.setPostDate(format.parse(time));
                    articleServiceImpl.save(article);
                    String regEx="[。？！?!]";
                    Pattern p =Pattern.compile(regEx);
                    /*按照句子结束符分割句子*/
                    String[] segments = p.split(text);
                    for(int location = 0 ; location<segments.length;location++){
                        String segment = segments[location];
                        Origin origin = new Origin();
                        origin.setSentence(segment);
                        origin.setSystemLabel(NLPTokenizer.analyze(segment).toString());
                        origin.setSource("明报");
                        origin.setLanguage("繁体");
                        origin.setStatus(OriginStatus.UNLABELED.getData());
                        origin.setArticleId(article.getId());
                        origin.setArticleLocation(location);
                        System.out.println(origin);
                        originServiceImpl.save(origin);
                    }
                }
            }catch (Exception e){
                e.printStackTrace();
                continue;
            }
        }
    }



    private static boolean isChinnese(String str) {
        String reg = "[\\u4E00-\\u9FA5]+";
        Matcher m = Pattern.compile(reg).matcher(str);
        if (m.find()) {
            return true;
        }else{
            return false;
        }
    }


    @Test
    public void group(){
        List<LabelResult> totalResults = labelResultMapper.countTotal(Long.valueOf(1));
        List<LabelResult> weekResults = labelResultMapper.countWeek(Long.valueOf(1));
        List<LabelResult> dailyResults = labelResultMapper.countDaily(Long.valueOf(1));
        System.out.println(totalResults.size());
        System.out.println(weekResults.size());
        System.out.println(dailyResults.size());
    }


}
