package com.qigetech.mark.search.service;

import com.qigetech.mark.result.label.entity.LabelResult;

import java.util.List;

/**
 * Created by panzejia on 2019-06-09
 * Project : qigetech-mark
 */
public interface ILabelResultSearchService {

    void addAndUpdateIndex(List<LabelResult> labelResults);

    String addAndUpdateIndex(LabelResult labelResult);

    void deleteIndexById(String id);

}
