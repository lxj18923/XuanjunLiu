package com.qigetech.mark.user.mapper.permission;


import com.qigetech.mark.user.entity.permission.SysUserRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author panzejia
 * @since 2018-11-29
 */
public interface SysUserRoleMapper extends BaseMapper<SysUserRole> {

}
