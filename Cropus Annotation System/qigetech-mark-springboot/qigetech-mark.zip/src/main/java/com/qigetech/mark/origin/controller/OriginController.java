package com.qigetech.mark.origin.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.qigetech.mark.origin.entity.Origin;
import com.qigetech.mark.origin.entity.vo.OriginLabelVO;
import com.qigetech.mark.origin.service.IOriginService;
import com.qigetech.mark.user.auth.utils.AuthUtils;
import com.qigetech.mark.user.entity.user.User;
import com.qigetech.mark.user.service.user.IUserService;
import com.qigetech.utils.resultbundle.ResultBundle;
import com.qigetech.utils.resultbundle.ResultBundleBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author panzejia
 * @since 2019-06-08
 */
@RestController
@RequestMapping("/origin")
public class OriginController {

    @Autowired
    private IOriginService originServiceImpl;

    @Autowired
    private ResultBundleBuilder resultBundleBuilder;

    @Autowired
    private IUserService userServiceImpl;

    @PostMapping
    public ResultBundle<Boolean> add(@RequestBody Origin origin){
        return resultBundleBuilder.bundle("Add origin",()->
                originServiceImpl.save(origin)
        );
    }

    @DeleteMapping("/{id}")
    public ResultBundle<Boolean> deleteById(@PathVariable String id){
        return resultBundleBuilder.bundle(id,()->
                originServiceImpl.removeById(id)
        );
    }

    @PutMapping
    public ResultBundle<Boolean> update(@RequestBody Origin origin){
        return resultBundleBuilder.bundle("Update origin",()->
                originServiceImpl.updateById(origin)
        );
    }

    @GetMapping("/{id}")
    public ResultBundle<Origin> getById(@PathVariable String id){
        return resultBundleBuilder.bundle(id,()->
                originServiceImpl.getById(id)
        );
    }

    @GetMapping("/list")
    public ResultBundle<IPage<Origin>> getList(@RequestParam(name = "current",defaultValue = "0")long current,
                                               @RequestParam(name = "size",defaultValue = "20")long size){
        Page<Origin> page = new Page<>(current,size);
        return resultBundleBuilder.bundle("get list",()->
                originServiceImpl.page(page,null)
        );
    }

    @GetMapping("/random")
    public ResultBundle<Origin> random(Authentication authentication){
        String username = AuthUtils.getUsername(authentication);
        User user = userServiceImpl.getOne(new QueryWrapper<User>().eq("name",username));
        Long userId = user.getId();
        String language = user.getLanguage();
        return resultBundleBuilder.bundle("get one by random",()->
                originServiceImpl.getOrigin(userId,language)
        );
    }

    @GetMapping("/skip")
    public ResultBundle<Boolean> skip(Authentication authentication){
        String username = AuthUtils.getUsername(authentication);
        User user = userServiceImpl.getOne(new QueryWrapper<User>().eq("name",username));
        Long userId = user.getId();
        return resultBundleBuilder.bundle("skip",()->
                originServiceImpl.skip(userId)
        );
    }

    @GetMapping("/page")
    public ResultBundle<IPage<OriginLabelVO>> getPage(@RequestParam(name = "current",defaultValue = "0")long current,
                                                      @RequestParam(name = "size",defaultValue = "20")long size,
                                                      Authentication authentication){
        String username = AuthUtils.getUsername(authentication);
        User user = userServiceImpl.getOne(new QueryWrapper<User>().eq("name",username));
        return resultBundleBuilder.bundle("get list",()->
                originServiceImpl.getOriginLabelPage(current,size,user)
        );
    }

}
