package com.qigetech.mark.origin.entity;

import lombok.Data;

/**
 * Created by panzejia on 2019-07-08
 * Project : qigetech-mark
 */
@Data
public class OriginUser {
    private Integer userId;
    private Integer originId;
}
