package com.qigetech.mark.search.service.impl;

import com.qigetech.mark.result.label.entity.LabelResult;
import com.qigetech.mark.search.entity.LabelResultSearch;
import com.qigetech.mark.search.mapper.LabelResultSearchRepository;
import com.qigetech.mark.search.service.ILabelResultSearchService;
import com.qigetech.mark.util.EncryptionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.query.IndexQuery;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * Created by panzejia on 2019-06-09
 * Project : qigetech-mark
 */
@Service
public class LabelResultSearchServiceImpl implements ILabelResultSearchService {

    @Autowired
    private ElasticsearchTemplate elasticsearchTemplate;

    @Resource
    private LabelResultSearchRepository labelResultSearchRepository;

    @Override
    public String addAndUpdateIndex(LabelResult labelResult) {
        LabelResultSearch labelResultSearch = new LabelResultSearch();
        BeanUtils.copyProperties(labelResult,labelResultSearch);
        IndexQuery indexQuery = new IndexQuery();
        indexQuery.setObject(labelResultSearch);
        indexQuery.setIndexName("cn_edu_bnu_mark_label_result");
        indexQuery.setType("label_result");
        return elasticsearchTemplate.index(indexQuery);
    }

    @Override
    public void addAndUpdateIndex(List<LabelResult> labelResults) {
        for(LabelResult result : labelResults){
            addAndUpdateIndex(result);
        }
    }

    @Override
    public void deleteIndexById(String id) {
        labelResultSearchRepository.deleteById(id);
    }
}
