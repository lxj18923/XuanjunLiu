package com.qigetech.mark.result.label.entity.vo;

import lombok.Data;

/**
 * Created by panzejia on 2019-06-11
 * Project : qigetech-mark
 */
@Data
public class LabelVO {
}
