package com.qigetech.mark.result.label.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.qigetech.mark.origin.entity.Origin;
import com.qigetech.mark.origin.entity.OriginStatus;
import com.qigetech.mark.origin.entity.OriginUser;
import com.qigetech.mark.origin.entity.vo.OriginLabelVO;
import com.qigetech.mark.origin.mapper.OriginUserMapper;
import com.qigetech.mark.origin.service.IOriginService;
import com.qigetech.mark.result.label.entity.LabelResult;
import com.qigetech.mark.result.label.entity.dto.LabelResultDTO;
import com.qigetech.mark.result.label.entity.vo.LabelResultVO;
import com.qigetech.mark.result.label.entity.vo.ProofreadingVO;
import com.qigetech.mark.result.label.mapper.LabelResultMapper;
import com.qigetech.mark.result.label.service.ILabelResultService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.qigetech.mark.search.service.ILabelResultSearchService;
import com.qigetech.mark.user.auth.utils.AuthUtils;
import com.qigetech.mark.user.entity.permission.Role;
import com.qigetech.mark.user.entity.user.User;
import com.qigetech.mark.user.service.permission.ISysRoleService;
import com.qigetech.mark.user.service.user.IUserService;
import com.qigetech.mark.util.EncryptionUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.awt.*;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author panzejia
 * @since 2019-06-08
 */
@Service
public class LabelResultServiceImpl extends ServiceImpl<LabelResultMapper, LabelResult> implements ILabelResultService {

    @Autowired
    private IOriginService originServiceImpl;

    @Autowired
    private IUserService userServiceImpl;

    @Autowired
    private ILabelResultSearchService labelResultSearchServiceImpl;

    @Resource
    private OriginUserMapper originUserMapper;

    @Override
    public ProofreadingVO getProofreading(){
        ProofreadingVO proofreading = new ProofreadingVO();
        Origin origin = originServiceImpl.getOne(new QueryWrapper<Origin>().eq("status",OriginStatus.VERIFICATION_FAILED.getData()).last("limit 1"));
        if(origin==null){
            return null;
        }
        proofreading.setOrigin(origin);
        List<LabelResultVO> labelResultVOS = new ArrayList<>();
        List<LabelResult> results = this.baseMapper.selectList(new QueryWrapper<LabelResult>().eq("origin_id",origin.getId()));
        Map<Integer,List<LabelResult>> resultMap = results.stream().collect(Collectors.groupingBy(LabelResult::getUserId));
        for(Integer userId : resultMap.keySet()){
            User user = userServiceImpl.getById(userId);
            List<LabelResult> userLabelResults = resultMap.get(userId);
            userLabelResults.sort((LabelResult result1,LabelResult result2)->result1.getLocation().compareTo(result2.getLocation()));
            final StringBuilder str = new StringBuilder();
            userLabelResults.forEach(labelResult -> {
                String encodeWord = labelResult.getWord();
                str.append(encodeWord+"/"+labelResult.getPartOfSpeech()+" ");
            });
            LabelResultVO resultVO = new LabelResultVO();
            resultVO.setOriginId(origin.getId());
            resultVO.setUserId(userId);
            resultVO.setUsername(user.getName());
            resultVO.setMarkContent(str.toString());
            resultVO.setMarkDate(userLabelResults.get(0).getMarkDate());
            labelResultVOS.add(resultVO);
        }
        proofreading.setLabelResults(labelResultVOS);
        return proofreading;
    }

    @Autowired
    private ISysRoleService sysRoleServiceImpl;

    @Override
    public Boolean save(LabelResultDTO labelResultDTO, Long userId){
        Origin origin = originServiceImpl.getById(labelResultDTO.getOriginId());
        if(origin.getStatus()==OriginStatus.UNLABELED.getData()){
            origin.setStatus(OriginStatus.MARK_ONCE.getData());
        }
        List<LabelResult> newResults = toLabelResults(labelResultDTO,userId);
        this.saveBatch(newResults);
        //存储新的originId
        Origin origin1 = originServiceImpl.getOriginByNoCheck(origin.getLanguage());
        originUserMapper.delete(new QueryWrapper<OriginUser>().eq("user_id",userId));
        OriginUser originUser1 = new OriginUser();
        originUser1.setUserId(userId.intValue());
        originUser1.setOriginId(origin1.getId());
        originUserMapper.insert(originUser1);

        return originServiceImpl.updateById(origin);
    }
    /**
    @Override
    public Boolean save(LabelResultDTO labelResultDTO, Long userId){
        Origin origin = originServiceImpl.getById(labelResultDTO.getOriginId());
        boolean needSaveStatus = false;
        //只有状态为未标注和标注一次才能使用本方法存入
        if(origin.getStatus()== OriginStatus.MARK_ONCE.getData()
                ||origin.getStatus()==OriginStatus.UNLABELED.getData()){
            needSaveStatus = true;
        }
        //原句的状态为“只标注一次”，则进入验证
        boolean status = true;
        if(origin.getStatus()== OriginStatus.MARK_ONCE.getData()){
            //获取数据库中已有的labelResult数据
            List<LabelResult> resultList = this.baseMapper.selectList(
                    new QueryWrapper<LabelResult>().eq("origin_id",labelResultDTO.getOriginId())
            );
            Map<Integer,LabelResult> resultMap = resultList.stream().collect(
                    Collectors.toMap(LabelResult::getLocation, result->result));
            for(LabelResultDTO.Word word : labelResultDTO.getWords()){
                LabelResult result = resultMap.get(word.getLocation());
                String encodeWord = result.getWord();
                if(!encodeWord.equals(word.getWord())
                        ||!result.getPartOfSpeech().equals(word.getPartOfSpeech())){
                    status = false;
                    break;
                }
            }
            //验证通过将origin的状态改为“验证成功”
            if(status){
                origin.setStatus(OriginStatus.VERIFICATION_SUCCESS.getData());
            }else{
                //验证通过改为“验证失败”
                origin.setStatus(OriginStatus.VERIFICATION_FAILED.getData());
            }
        }
        //原句状态为“未标注”，就直接将结果存到数据并修改原句状态
        if(origin.getStatus()==OriginStatus.UNLABELED.getData()){
            origin.setStatus(OriginStatus.MARK_ONCE.getData());
        }
        //存入到数据库中
        if(needSaveStatus){
            List<LabelResult> newResults = toLabelResults(labelResultDTO,userId);
            this.saveBatch(newResults);
            if(status){
                labelResultSearchServiceImpl.addAndUpdateIndex(newResults);
            }
        }
        //存储新的originId
        Origin origin1 = originServiceImpl.getOriginByRandom(userId,origin.getLanguage());
        originUserMapper.delete(new QueryWrapper<OriginUser>().eq("user_id",userId));
        OriginUser originUser1 = new OriginUser();
        originUser1.setUserId(userId.intValue());
        originUser1.setOriginId(origin1.getId());
        originUserMapper.insert(originUser1);

        return originServiceImpl.updateById(origin);
    }
    */
    @Override
    public Map<String,Object> getOriginListByRole(long current, long size, User user){
        List<Role> roles = sysRoleServiceImpl.selectRoleByUserId(user.getId());
        boolean listStatus = false;
        for(Role role : roles){
            if(StringUtils.equals("标注人员",role.getName())){
                listStatus = true;
                break;
            }
        }
        Page<LabelResult> page = new Page<>(current,size);
        QueryWrapper<LabelResult> queryWrapper = new QueryWrapper<LabelResult>().orderByDesc("mark_date").groupBy("origin_id");
        if(listStatus){
            queryWrapper.eq("user_id",user.getId());
        }
        IPage<LabelResult> labelResultIPage = this.page(page,queryWrapper);
        List<LabelResult> labelResults = labelResultIPage.getRecords();
        List<Integer> originIds = labelResults.stream().map(LabelResult::getOriginId).collect(Collectors.toList());
        Map<String,Object> map = new HashMap<>();
        map.put("originIds",originIds);
        map.put("total",page.getTotal());
        return map;
    }


    @Override
    public Boolean update(LabelResultDTO labelResultDTO, Long userId){
        //先删后加
        this.remove(new QueryWrapper<LabelResult>().eq("origin_id",labelResultDTO.getOriginId()).eq("user_id",userId));
        List<LabelResult> newResults = toLabelResults(labelResultDTO,userId);
        return this.saveBatch(newResults);
    }


    @Override
    public List<LabelResultVO> getLabelResultByOriginId (Integer originId){
        List<LabelResultVO> labelResultVOS = new ArrayList<>();
        List<LabelResult> resultList = this.baseMapper.selectList(
                new QueryWrapper<LabelResult>().eq("origin_id",originId)
        );
        Map<Integer,List<LabelResult>> resultMap = resultList.stream().collect(Collectors.groupingBy(LabelResult::getUserId));
        for(Integer key : resultMap.keySet()){
            List<LabelResult> labelResults = resultMap.get(key);
            User user = userServiceImpl.getById(key);
            LabelResultVO labelResultVO = new LabelResultVO();
            labelResultVO.setUserId(key);
            labelResultVO.setUsername(user.getName());
            labelResultVO.setMarkDate(labelResults.get(0).getMarkDate());
            labelResultVO.setOriginId(originId);
            labelResults.sort((LabelResult result1,LabelResult result2)->result1.getLocation().compareTo(result2.getLocation()));
            final StringBuilder str = new StringBuilder();
            labelResults.forEach(labelResult -> {
                String encodeWord = labelResult.getWord();
                str.append(encodeWord+"/"+labelResult.getPartOfSpeech()+" ");
            });
            labelResultVO.setMarkContent(str.toString());
            labelResultVOS.add(labelResultVO);
        }
        return labelResultVOS;
    }

    @Override
    public Boolean saveProofreading(LabelResultDTO labelResultDTO, Long userId){

        Origin origin = originServiceImpl.getById(labelResultDTO.getOriginId());
        //修改原句状态
        origin.setStatus(OriginStatus.AFTER_PROOFREADING.getData());
        List<LabelResult> newResults = toLabelResults(labelResultDTO,userId);
        this.saveBatch(newResults);
        labelResultSearchServiceImpl.addAndUpdateIndex(newResults);
        return originServiceImpl.updateById(origin);
        //存入到数据库中
    }

    @Override
    public HashMap<String,Integer> count(long userId){
        HashMap<String,Integer> counts = new HashMap<>(3);
        List<LabelResult> totalResults = this.baseMapper.countTotal(userId);
        List<LabelResult> weekResults = this.baseMapper.countWeek(userId);
        List<LabelResult> dailyResults = this.baseMapper.countDaily(userId);
        counts.put("total",totalResults.size());
        counts.put("week",weekResults.size());
        counts.put("daily",dailyResults.size());
        return counts;
    }

    private ArrayList<LabelResult> toLabelResults(LabelResultDTO labelResultDTO,Long userId){
        ArrayList<LabelResult> newResults = new ArrayList<>();
        for(LabelResultDTO.Word word : labelResultDTO.getWords()){
            LabelResult labelResult = new LabelResult();
            labelResult.setWord(word.getWord());
            labelResult.setPartOfSpeech(word.getPartOfSpeech());
            labelResult.setLocation(word.getLocation());
            labelResult.setOriginId(labelResultDTO.getOriginId());
            labelResult.setUserId(userId.intValue());
            labelResult.setMarkDate(new Date());
            newResults.add(labelResult);
        }
        return newResults;
    }



}
