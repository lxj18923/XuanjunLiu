package com.qigetech.mark.result.label.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import java.time.LocalDate;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author panzejia
 * @since 2019-06-08
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName("label_result")
public class LabelResult implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    private String word;

    private String partOfSpeech;

    private Integer location;

    private Integer originId;

    private Integer userId;

    private Date markDate;


}
