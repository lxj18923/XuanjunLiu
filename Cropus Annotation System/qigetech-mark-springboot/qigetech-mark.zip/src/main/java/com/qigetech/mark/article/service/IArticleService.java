package com.qigetech.mark.article.service;

import com.qigetech.mark.article.entity.Article;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author panzejia
 * @since 2019-06-17
 */
public interface IArticleService extends IService<Article> {

}
