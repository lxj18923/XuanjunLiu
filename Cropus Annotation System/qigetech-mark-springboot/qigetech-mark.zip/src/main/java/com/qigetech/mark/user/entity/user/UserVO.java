package com.qigetech.mark.user.entity.user;

import lombok.Data;

import java.util.Date;

@Data
public class UserVO {

    private long id;

    private String name;

    private String remark;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 创建用户
     */
    private String createUser;

    /**
     * 更新时间
     */
    private Date updateTime;

    /**
     * 更新用户
     */
    private String updateUser;

}
