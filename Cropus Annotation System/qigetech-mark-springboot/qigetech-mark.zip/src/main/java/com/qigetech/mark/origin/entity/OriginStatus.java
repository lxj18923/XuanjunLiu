package com.qigetech.mark.origin.entity;

public enum OriginStatus {

    /**
     * @Author panzejia
     * @Description 未标注
     * @Date 15:15 2019-06-09
     * @Param
     * @return
     **/
    UNLABELED(0),

    /**
     * @Author panzejia
     * @Description 标注一次
     * @Date 15:15 2019-06-09
     * @Param
     * @return
     **/
    MARK_ONCE(1),

    /**
     * @Author panzejia
     * @Description 交叉验证成功
     * @Date 15:15 2019-06-09
     * @Param
     * @return
     **/
    VERIFICATION_SUCCESS(2),

    /**
     * @Author panzejia
     * @Description 交叉验证失败
     * @Date 15:18 2019-06-09
     * @Param 
     * @return 
     **/
    VERIFICATION_FAILED(3),

    /**
     * @Author panzejia
     * @Description 校对后
     * @Date 17:15 2019-06-18
     * @Param []
     * @return
     **/
    AFTER_PROOFREADING(4);


    private int data;

    private OriginStatus(int data) {
        this.data = data;
    }

    public int getData() {
        return data;
    }

    public void setData(int data) {
        this.data = data;
    }

}
