package com.qigetech.mark.origin.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.qigetech.mark.origin.entity.Origin;
import com.qigetech.mark.origin.entity.OriginStatus;
import com.qigetech.mark.origin.entity.OriginUser;
import com.qigetech.mark.origin.entity.vo.OriginLabelVO;
import com.qigetech.mark.origin.mapper.OriginMapper;
import com.qigetech.mark.origin.mapper.OriginUserMapper;
import com.qigetech.mark.origin.service.IOriginService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.qigetech.mark.result.label.entity.LabelResult;
import com.qigetech.mark.result.label.entity.vo.LabelResultVO;
import com.qigetech.mark.result.label.service.ILabelResultService;
import com.qigetech.mark.search.service.IOriginSearchService;
import com.qigetech.mark.user.entity.permission.Role;
import com.qigetech.mark.user.entity.user.User;
import com.qigetech.mark.user.service.permission.ISysRoleService;
import com.qigetech.mark.util.EncryptionUtils;
import io.swagger.models.auth.In;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author panzejia
 * @since 2019-06-08
 */
@Service
public class OriginServiceImpl extends ServiceImpl<OriginMapper, Origin> implements IOriginService {

    @Autowired
    private IOriginSearchService originSearchServiceImpl;

    @Autowired
    private ILabelResultService labelResultServiceImpl;

    @Resource
    private OriginUserMapper originUserMapper;

    @Override
    public Origin getOrigin(Long userId,String language){
        OriginUser originUser = originUserMapper.selectOne(new QueryWrapper<OriginUser>().eq("user_id",userId));
        Origin origin ;
        if(originUser==null||originUser.getOriginId()==null){
            origin = getOriginByNoCheck(language);
            OriginUser originUser1 = new OriginUser();
            originUser1.setUserId(userId.intValue());
            originUser1.setOriginId(origin.getId());
            originUserMapper.insert(originUser1);
        }else{
            origin = this.getById(originUser.getOriginId());
        }
        return origin;
    }

    @Override
    public boolean skip(Long userId){
        return this.retBool(originUserMapper.delete(new QueryWrapper<OriginUser>().eq("user_id",userId)));
    }

    @Override
    public Origin getOriginByNoCheck(String language){
        List<Origin> list = this.baseMapper.selectList(
                new QueryWrapper<Origin>().eq("status", OriginStatus.UNLABELED.getData())
                        .eq("language",language)
        );
        if(list.size()!=0){
            Random random = new Random();
            int num = random.nextInt(list.size());
            return list.get(num);

        }else{
            return null;
        }
    }

    @Override
    public Origin getOriginByRandom(Long userId,String language){
        if(StringUtils.isEmpty(language)){
            language = "繁体";
        }
        boolean isNeedUnlabeled = false;
        //第二个人优先处理只标注一次的数据
        List<Origin> list = this.baseMapper.selectList(
                new QueryWrapper<Origin>().eq("status", OriginStatus.MARK_ONCE.getData())
                .eq("language",language)
        );
        //如果已有标注，判断是否同一个用户
        if(list.size()!=0){
            LabelResult labelResult = labelResultServiceImpl.getOne(
                    new QueryWrapper<LabelResult>().eq("origin_id",list.get(0).getId()).groupBy("user_id")
            );
            //如果是同一个用户就需要新数据
            if(labelResult.getUserId()==userId.intValue()){
                isNeedUnlabeled=true;
            }
            //如果有人已经标过也需要新数据
            if(originUserMapper.selectOne(new QueryWrapper<OriginUser>().eq("origin_id",labelResult.getOriginId()))!=null){
                isNeedUnlabeled=true;
            }
        }else {
            //如果没有标注就需要新数据
            isNeedUnlabeled=true;
        }
        //如果没有只标注一次的数据则获取没有标注的数据
        if(isNeedUnlabeled){
            list = this.baseMapper.selectList(
                    new QueryWrapper<Origin>().eq("status", OriginStatus.UNLABELED.getData())
                            .eq("language",language)
            );
        }
        //如果也没有没标注的数据，则返回空
        if(list.size()==0){
            return null;
        }else{
            Random random = new Random();
            int num = random.nextInt(list.size());
            return list.get(num);
        }
    }

    @Override
    public boolean save(Origin origin) {
        originSearchServiceImpl.addAndUpdateIndex(origin);
        return this.retBool(this.baseMapper.insert(origin));
    }

    @Override
    public boolean updateById(Origin origin) {
        originSearchServiceImpl.addAndUpdateIndex(origin);
        return this.retBool(this.baseMapper.updateById(origin));
    }

    @Override
    public Page<OriginLabelVO> getOriginLabelPage(long current, long size, User user){
        Page<OriginLabelVO> originLabelVOPage = new Page<>(current,size);
        List<OriginLabelVO> originLabelVOS = new ArrayList<>();
        Map<String,Object> map = labelResultServiceImpl.getOriginListByRole(current,size,user);
        List<Integer> originIds = (List<Integer>) map.get("originIds");
        long total = (long) map.get("total");
        List<Origin> origins = this.baseMapper.selectBatchIds(originIds);
        //根据当前页获取分词内容
        for(Origin origin:origins){
            List<LabelResultVO> labelResultVOS = labelResultServiceImpl.getLabelResultByOriginId(origin.getId());
            OriginLabelVO originLabelVO = new OriginLabelVO();
            BeanUtils.copyProperties(origin,originLabelVO);
            originLabelVO.setLabelResults(labelResultVOS);
            originLabelVOS.add(originLabelVO);
        }
        originLabelVOPage.setTotal(total);
        originLabelVOPage.setRecords(originLabelVOS);
        return originLabelVOPage;
    }
}
