package com.qigetech.mark.search.service.impl;

import com.qigetech.mark.origin.entity.Origin;
import com.qigetech.mark.search.entity.OriginSearch;
import com.qigetech.mark.search.mapper.OriginSearchRepository;
import com.qigetech.mark.search.service.IOriginSearchService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.query.IndexQuery;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * Created by panzejia on 2019-06-09
 * Project : qigetech-mark
 */
@Service
public class OriginSearchImpl implements IOriginSearchService {

    @Autowired
    private ElasticsearchTemplate elasticsearchTemplate;

    @Resource
    private OriginSearchRepository originSearchRepository;

    @Override
    public void addAndUpdateIndex(Origin origin){
        OriginSearch originSearch = new OriginSearch();
        BeanUtils.copyProperties(origin,originSearch);
        addAndUpdateIndex(originSearch);
    }

    @Override
    public void addAndUpdateIndex(OriginSearch originSearch){
        IndexQuery indexQuery = new IndexQuery();
        indexQuery.setId(String.valueOf(originSearch.getId()));
        indexQuery.setObject(originSearch);
        indexQuery.setIndexName("cn_edu_bnu_mark_origin");
        indexQuery.setType("origin");
        elasticsearchTemplate.index(indexQuery);
    }

    @Override
    public void deleteIndexById(String id) {
        originSearchRepository.deleteById(id);
    }

}
