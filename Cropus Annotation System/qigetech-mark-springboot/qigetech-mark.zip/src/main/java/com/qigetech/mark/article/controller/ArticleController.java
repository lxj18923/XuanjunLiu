package com.qigetech.mark.article.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author panzejia
 * @since 2019-06-17
 */
@RestController
@RequestMapping("/article/article")
public class ArticleController {

}
