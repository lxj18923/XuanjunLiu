package com.qigetech.mark.search.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;

import java.util.Date;

/**
 * Created by panzejia on 2019-06-09
 * Project : qigetech-mark
 */
@Data
@EqualsAndHashCode()
@Accessors(chain = true)
@Document(indexName = "cn_edu_bnu_mark_label_result",type = "label_result", shards = 5,replicas = 0, refreshInterval = "-1")
public class LabelResultSearch {

    @Id
    private String id;

    @Field
    private String word;

    @Field
    private String partOfSpeech;

    @Field
    private Integer location;

    @Field
    private Integer originId;

    @Field
    private Integer userId;

    @Field
    private Date markDate;

}
