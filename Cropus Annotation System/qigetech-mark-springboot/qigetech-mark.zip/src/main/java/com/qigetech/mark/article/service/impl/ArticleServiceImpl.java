package com.qigetech.mark.article.service.impl;

import com.qigetech.mark.article.entity.Article;
import com.qigetech.mark.article.mapper.ArticleMapper;
import com.qigetech.mark.article.service.IArticleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author panzejia
 * @since 2019-06-17
 */
@Service
public class ArticleServiceImpl extends ServiceImpl<ArticleMapper, Article> implements IArticleService {

}
