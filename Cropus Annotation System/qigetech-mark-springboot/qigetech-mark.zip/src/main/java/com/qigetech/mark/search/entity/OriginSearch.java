package com.qigetech.mark.search.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;

/**
 * Created by panzejia on 2019-06-09
 * Project : qigetech-mark
 */
@Data
@EqualsAndHashCode()
@Accessors(chain = true)
@Document(indexName = "cn_edu_bnu_mark_origin",type = "origin", shards = 1,replicas = 0, refreshInterval = "-1")
public class OriginSearch {

    @Id
    private String id;

    @Field
    private String sentence;

    @Field
    private String systemLabel;

    @Field
    private String language;

    @Field
    private String source;

    @Field
    private Integer status;

    @Field
    private String remark;
}
