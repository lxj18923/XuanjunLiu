package com.qigetech.mark.search.mapper;

import com.qigetech.mark.search.entity.LabelResultSearch;
import com.qigetech.mark.search.entity.OriginSearch;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

/**
 * Created by panzejia on 2019-06-09
 * Project : qigetech-mark
 */
@Component
public interface LabelResultSearchRepository extends ElasticsearchRepository<LabelResultSearch,String> {
}
