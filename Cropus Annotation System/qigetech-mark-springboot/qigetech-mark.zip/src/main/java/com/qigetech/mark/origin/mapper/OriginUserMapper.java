package com.qigetech.mark.origin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.qigetech.mark.origin.entity.Origin;
import com.qigetech.mark.origin.entity.OriginUser;
import org.springframework.stereotype.Repository;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author panzejia
 * @since 2019-06-08
 */
@Repository
public interface OriginUserMapper extends BaseMapper<OriginUser> {

}
