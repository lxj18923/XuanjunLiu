package com.qigetech.mark.search.controller;

/**
 * Created by panzejia on 2019-06-09
 * Project : qigetech-mark
 */
public class LabelResultSearchController {
}
