package com.qigetech.mark.origin.mapper;

import com.qigetech.mark.origin.entity.Origin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author panzejia
 * @since 2019-06-08
 */
public interface OriginMapper extends BaseMapper<Origin> {

}
