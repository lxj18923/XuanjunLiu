package com.qigetech.mark.search.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.qigetech.mark.origin.entity.Origin;
import com.qigetech.mark.result.label.entity.LabelResult;
import com.qigetech.mark.search.entity.OriginSearch;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author panzejia
 * @since 2019-06-08
 */
public interface IOriginSearchService {
    void addAndUpdateIndex(Origin origin);
    void addAndUpdateIndex(OriginSearch originSearch);
    void deleteIndexById(String id);
}
