package com.qigetech.mark.result.label.mapper;

import com.qigetech.mark.result.label.entity.LabelResult;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.qigetech.mark.user.entity.permission.SysPermission;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author panzejia
 * @since 2019-06-08
 */
@Repository
public interface LabelResultMapper extends BaseMapper<LabelResult> {

    @Select("SELECT * FROM label_result  WHERE user_id = #{userId} AND to_days(mark_date) = to_days(now()) GROUP BY origin_id ")
    List<LabelResult> countDaily(@Param("userId") long userId);

    @Select("SELECT * FROM label_result  WHERE user_id = #{userId} AND DATE_SUB(CURDATE(), INTERVAL 7 DAY)  <= mark_date GROUP BY origin_id ")
    List<LabelResult> countWeek(@Param("userId") long userId);

    @Select("SELECT * FROM label_result  WHERE user_id = #{userId} GROUP BY origin_id ")
    List<LabelResult> countTotal(@Param("userId") long userId);
}
